#include<stdio.h>
#include "point.h"
#pragma once

Point getScale2xPoint(const Point* pi);