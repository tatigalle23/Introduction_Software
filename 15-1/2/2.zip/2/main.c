#include<stdio.h>
#include "point.h"
#include "pointmath.h"

int main(){
    Point p1;
    p1.xpos;
    p1.ypos;
    scanf("%d %d", &p1.xpos, &p1.ypos);

    Point p2=getScale2xPoint(&p1);
    printf("%d %d", p2.xpos, p2.ypos);
}