#include "pointmath.h"
#include "point.h"

Point getScale2xPoint(const Point* pi){
    Point pb;
    pb.xpos=pi->xpos*2;
    pb.ypos=pi->ypos*2;
    return pb;
    
}

